package com.pintarngoding.cataloguemovieuiux.ui;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.pintarngoding.cataloguemovieuiux.R;

public class ChangeLanguageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_language);
    }
}
